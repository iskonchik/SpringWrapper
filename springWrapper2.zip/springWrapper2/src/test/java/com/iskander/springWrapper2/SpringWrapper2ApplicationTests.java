package com.iskander.springWrapper2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWrapper2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
